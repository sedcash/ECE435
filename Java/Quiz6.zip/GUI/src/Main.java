
import org.json.JSONException;
import java.io.IOException;
import java.util.Scanner;


public  class Main{
    public static void main(String[] args) {

        MainUI temp = new MainUI();
        temp.run();
    }
}
